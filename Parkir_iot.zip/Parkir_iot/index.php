<?php
require __DIR__ . '/vendor/autoload.php';
session_start();
use PhpMqtt\Client\MqttClient;
date_default_timezone_set('Asia/Jakarta');
/* KONEKSI */
$conn = new mysqli("localhost","root","","parkir_iot");
if($conn->connect_error){ die("Koneksi gagal"); }

/* SCAN */
if(isset($_POST['card'])){

    $card = $_POST['card'];

    $cek = $conn->query("SELECT * FROM parkir 
                         WHERE card_id='$card' 
                         AND status='IN'");

    if($cek->num_rows > 0){

        // KELUAR
        $data = $cek->fetch_assoc();
        $id = (int)$data['id'];

        $conn->query("UPDATE parkir SET
            checkout_time = NOW(),
            status='WAITING'
            WHERE id=$id");

    } else {

        // MASUK

        $conn->query("INSERT INTO parkir
            (card_id, checkin_time, status)
            VALUES
            ('$card',NOW(),'IN')");
    }

    header("Location:index.php");
    exit();
}

/* APPROVE */
if(isset($_GET['approve'])) {

    $id = intval($_GET['approve']);

    $result = $conn->query("SELECT * FROM parkir WHERE id='$id'");
    $data = $result->fetch_assoc();

    $masuk = strtotime($data['checkin_time']);
    $keluar = strtotime($data['checkout_time']);

    $durasi = round(($keluar - $masuk)/3600, 2);
    $biaya = round($durasi * 2000);

    $conn->query("UPDATE parkir SET
        duration='$durasi',
        fee='$biaya',
        status='OUT'
        WHERE id='$id'");

    // 🔥 KIRIM KE MQTT
    $mqtt = new MqttClient('broker.emqx.io', 1883, 'web-client-' . rand());
    $mqtt->connect();

    $mqtt->publish('parking/caier/servo', json_encode([
        'id' => $id
    ]), 0);

    $mqtt->disconnect();

    header("Location:index.php");
    exit();
}

if(!isset($_SESSION['user'])){
    header("Location: view/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Sistem Parkir RFID</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',sans-serif;}

body{
    background:linear-gradient(135deg,#141e30,#243b55);
}

/* NAVBAR */
.navbar{
    background:#fff;
    padding:18px 50px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 18px rgba(0,0,0,0.15);
}

.navbar h2{
    color:#243b55;
    font-size:20px;
}

/* LOGOUT */
.logout-btn{
    background:#ff4d4d;
    padding:10px 20px;
    border-radius:25px;
    color:#fff;
    text-decoration:none;
    font-weight:600;
}

/* WRAPPER */
.wrapper{
    padding:30px 60px;
}

/* CARD */
.container{
    background:#fff;
    padding:25px;
    border-radius:16px;
    margin-bottom:25px;
    box-shadow:0 8px 20px rgba(0,0,0,0.15);
}

/* TITLE */
.section-title{
    font-size:18px;
    font-weight:600;
    margin-bottom:15px;
    color:#243b55;
}

/* INPUT */
input{
    padding:12px;
    border-radius:10px;
    border:1px solid #ccc;
    width:260px;
}

/* BUTTON */
button{
    padding:10px 18px;
    border:none;
    border-radius:10px;
    color:white;
    cursor:pointer;
    font-weight:600;
}

.scan{background:#ff9800;}
.approve{background:#28a745;}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}

th,td{
    padding:12px;
    text-align:center;
}

th{
    background:#243b55;
    color:white;
}

td{
    border-bottom:1px solid #eee;
}

tr:hover td{
    background:#f5f5f5;
}

/* STATUS */
.status-in{color:green;font-weight:bold;}
.status-out{color:red;font-weight:bold;}
</style>

</head>
<body>

<div class="navbar">
    <h2>SISTEM PARKIR RFID IOT</h2>
    <a href="view/logout.php" class="logout-btn">Logout</a>
</div>

<div class="wrapper">

<!-- SCAN -->
<div class="container">
<div class="section-title">Scan Kartu RFID</div>
<form method="POST">
<input type="text" name="card" placeholder="Tempel / Ketik Card ID" required>
<button class="scan" type="submit">Scan</button>
</form>
</div>

<!-- SEDANG PARKIR -->
<div class="container">
<div class="section-title">Sedang Parkir</div>
<table>
<tr>
<th>ID</th>
<th>Card</th>
<th>Masuk</th>
<th>Durasi</th>
<th>Biaya</th>
<th>Status</th>
</tr>

<?php
$data = $conn->query("
SELECT *,
ROUND(TIMESTAMPDIFF(SECOND, checkin_time, NOW()) / 3600, 2) as duration,
ROUND((TIMESTAMPDIFF(SECOND, checkin_time, NOW()) / 3600) * 2000, 0) as fee
FROM parkir WHERE status='IN'
");

while($row=$data->fetch_assoc()){
echo "<tr>
<td>{$row['id']}</td>
<td>{$row['card_id']}</td>
<td>{$row['checkin_time']}</td>
<td>{$row['duration']} jam</td>
<td>Rp {$row['fee']}</td>
<td class='status-in'>IN</td>
</tr>";
}
?>
</table>
</div>

<!-- ANTRIAN -->
<div class="container">
<div class="section-title">Antrian Keluar</div>
<table>
<tr>
<th>ID</th>
<th>Card</th>
<th>Durasi</th>
<th>Biaya</th>
<th>Aksi</th>
</tr>

<?php
$data = $conn->query("
SELECT *,
ROUND(TIMESTAMPDIFF(SECOND, checkin_time, checkout_time) / 3600, 2) as duration,
ROUND((TIMESTAMPDIFF(SECOND, checkin_time, checkout_time) / 3600) * 2000, 0) as fee
FROM parkir WHERE status='WAITING'
");

while($row=$data->fetch_assoc()){
echo "<tr>
<td>{$row['id']}</td>
<td>{$row['card_id']}</td>
<td>{$row['duration']} jam</td>
<td>Rp {$row['fee']}</td>
<td>
<a href='?approve={$row['id']}'>
<button class='approve'>Setujui</button>
</a>
</td>
</tr>";
}
?>
</table>
</div>

<!-- RIWAYAT -->
<div class="container">
<div class="section-title">Riwayat Parkir</div>
<table>
<tr>
<th>ID</th>
<th>Card</th>
<th>Masuk</th>
<th>Keluar</th>
<th>Durasi</th>
<th>Biaya</th>
<th>Status</th>
</tr>

<?php
$data = $conn->query("SELECT * FROM parkir WHERE status='OUT' ORDER BY id DESC");

while($row=$data->fetch_assoc()){
echo "<tr>
<td>{$row['id']}</td>
<td>{$row['card_id']}</td>
<td>{$row['checkin_time']}</td>
<td>{$row['checkout_time']}</td>
<td>{$row['duration']} jam</td>
<td>Rp {$row['fee']}</td>
<td class='status-out'>OUT</td>
</tr>";
}
?>
</table>
</div>

</div>

<script>
let isTyping = false;

const input = document.querySelector('input[name="card"]');

input.addEventListener('focus', ()=> isTyping = true);
input.addEventListener('blur', ()=> isTyping = false);

setInterval(()=>{
    if(!isTyping){
        location.reload();
    }
},3000);
</script>

</body>
</html>