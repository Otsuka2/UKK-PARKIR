<?php
session_start();

/* ======================
   KONEKSI DATABASE
====================== */
$conn = new mysqli("localhost", "root", "", "parkir_iot");

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

/* ======================
   PROSES LOGIN
====================== */
if(isset($_POST['login'])){

    $user = $_POST['username'];
    $pass = $_POST['password'];

    $query = "SELECT * FROM users 
              WHERE username='$user' 
              AND password='$pass'";

    $cek = $conn->query($query);

    if($cek && $cek->num_rows > 0){
        $_SESSION['user'] = $user;
        header("Location: ../index.php");
        exit();
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login Parkir</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI',sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
}

.login-box{
    background:white;
    padding:40px;
    width:350px;
    border-radius:20px;
    box-shadow:0 15px 40px rgba(0,0,0,0.4);
    text-align:center;
}

.login-box h2{
    margin-bottom:20px;
    color:#2c5364;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #ccc;
}

input:focus{
    border-color:#2c5364;
    outline:none;
}

button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#2c5364;
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#1b3b4d;
}

.error{
    background:#ffd6d6;
    color:#cc0000;
    padding:8px;
    border-radius:8px;
    margin-bottom:10px;
}
</style>

</head>
<body>

<div class="login-box">
<h2>Login Sistem Parkir</h2>

<?php
if(isset($error)){
    echo "<div class='error'>$error</div>";
}
?>

<form method="POST">
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button name="login">Login</button>
</form>

</div>

</body>
</html>