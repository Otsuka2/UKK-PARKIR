<?php
session_start();
session_destroy();

// karena logout.php ada di folder view
header("Location: login.php");
exit();
?>