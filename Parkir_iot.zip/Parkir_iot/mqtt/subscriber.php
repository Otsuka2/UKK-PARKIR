<?php
require __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../model/Parkir.php';
require __DIR__ . '/../model/ParkingModel.php';

use PhpMqtt\Client\MqttClient;
use PhpMqtt\Client\ConnectionSettings;

$model = new ParkingModel($conn);

$server = 'broker.emqx.io';
$port = 1883;

while (true) {
    try {
        $clientId = 'php-smartparking-' . rand(1000,9999);

        echo "Connecting to MQTT...\n";

        $mqtt = new MqttClient($server, $port, $clientId);

        $connectionSettings = (new ConnectionSettings)
            ->setKeepAliveInterval(60);

        $mqtt->connect($connectionSettings, true);

        echo "Connected!\n";

        // ================= ENTRY =================
        $mqtt->subscribe('parking/caier/entry/rfid', function($topic, $message) use ($mqtt, $model) {

            echo "ENTRY: $message\n";

            $data = json_decode($message, true);

            if ($data === null) {
                echo "JSON ERROR: " . json_last_error_msg() . "\n";
                return;
            }

            if (!isset($data['idCard'])) {
                echo "idCard tidak ada\n";
                return;
            }

            $idCard = trim($data['idCard']);

            if ($idCard === "") {
                echo "idCard kosong\n";
                return;
            }

            echo "ID Card: $idCard\n";

            try {
                $client = new \GuzzleHttp\Client();

                if ($model->checkIn($idCard))
                {
                    echo "OPEN GATE\n";
                    $mqtt->publish('parking/caier/entry/servo', 'OPEN', 0);
                    $mqtt->publish('parking/caier/lcd', $resData['message'] ?? 'Berhasil', 0);
                }
                else
                {
                    $mqtt->publish('parking/caier/lcd', 'Check-in gagal', 0);
                }

            } catch (\Exception $e) {
                echo "API ERROR: " . $e->getMessage() . "\n";
            }

        }, 0);
        $mqtt->subscribe('parking/caier/servo', function ($topic, $message) use ($mqtt) {

            echo "SERVO CMD: $message\n";

            $data = json_decode($message, true);

            if (!$data || !isset($data['id'])) {
                echo "Data tidak valid\n";
                return;
            }

            echo "APPROVE ID: " . $data['id'] . "\n";

            $mqtt->publish('parking/caier/exit/servo', 'OPEN', 0);
            echo "OPEN GATE\n";

        }, 0);
        // ================= EXIT =================
        $mqtt->subscribe('parking/caier/exit/rfid', function ($topic, $message) use ($mqtt, $model) {

            echo "EXIT: $message\n";

            $data = json_decode($message, true);

            if ($data === null || !isset($data['idCard'])) {
                echo "Data invalid\n";
                return;
            }

            $idCard = trim($data['idCard']);

            try {
                $client = new \GuzzleHttp\Client();

                $fee = $model->checkOut($idCard);

                if ($fee !== false)
                {
                    $mqtt->publish('parking/caier/lcd', "Durasi: 1|Total: $fee", 0);
                }
                //else
                {
                    $mqtt->publish('parking/caier/lcd', 'Checkout gagal', 0);
                }

            } catch (\Exception $e) {
                echo "API ERROR: " . $e->getMessage() . "\n";
            }

        }, 0);

        // loop (blocking)
        $mqtt->loop(true);

    } catch (\Exception $e) {
        echo "MQTT ERROR: " . $e->getMessage() . "\n";
        echo "Reconnect 3 detik...\n";
        sleep(3);
    }
}