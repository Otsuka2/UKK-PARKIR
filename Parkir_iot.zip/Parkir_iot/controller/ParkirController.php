<?php
session_start();
require_once __DIR__ . '/../model/Parkir.php';
require_once __DIR__ . '/../config/koneksi.php';

class ParkirController {
    private $model;

    public function __construct() {
        global $conn;
        $this->model = new Parkir($conn);
    }

    public function login() {
        if(isset($_POST['username'])) {
            $user = $this->model->login($_POST['username'], $_POST['password']);
            if($user) {
                $_SESSION['user'] = $user['username'];
                header("Location: index.php?action=dashboard");
                exit;
            } else {
                $error = "Username / Password salah";
            }
        }
        require_once __DIR__ . '/../view/login.php';
    }

    public function dashboard() {
        $this->checkLogin();

        $current = $this->model->getCurrentParkir();
        $checkout = $this->model->getWaiting();

        require_once __DIR__ . '/../view/dashboard.php';
    }

    public function checkin() {
        $this->checkLogin();

        if(isset($_POST['card_id'])) {
            if($this->model->checkin($_POST['card_id'])) {
                $success = "Kendaraan check-in berhasil";
            } else {
                $error = "Kendaraan sudah parkir";
            }
        }

        require_once __DIR__ . '/../view/checkin.php';
    }

    public function checkout() {
        $this->checkLogin();

        if(isset($_POST['card_id'])) {

            $id = $this->model->checkout($_POST['card_id']);

            if($id) {
                $_SESSION['struk'] = $id;
                header("Location: index.php?action=struk");
                exit;
            } else {
                $error = "Kendaraan belum check-in atau sudah checkout";
            }
        }

        require_once __DIR__ . '/../view/checkout.php';
    }

    public function struk() {
        $this->checkLogin();

        if(!isset($_SESSION['struk'])) {
            header("Location: index.php?action=dashboard");
            exit;
        }

        $data = $this->model->getTransaction($_SESSION['struk']);
        unset($_SESSION['struk']);

        require_once __DIR__ . '/../view/struk.php';
    }

    public function history() {
        $this->checkLogin();

        $histori = $this->model->getHistory();

        require_once __DIR__ . '/../view/history.php';
    }

    public function complete() {
        $this->checkLogin();

        if(isset($_GET['id'])) {
            $this->model->complete($_GET['id']);
        }

        header("Location: index.php?action=dashboard");
    }

    public function logout() {
        session_destroy();
        header("Location: index.php?action=login");
        exit;
    }

    private function checkLogin() {
        if(!isset($_SESSION['user'])) {
            header("Location: index.php?action=login");
            exit;
        }
    }
}
?>