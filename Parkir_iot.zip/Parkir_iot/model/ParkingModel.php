<?php
date_default_timezone_set('Asia/Jakarta');
class ParkingModel
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    // ====================
    // CHECK IN (FIX TOTAL)
    // ====================
    public function checkIn($card_id)
    {
        try {

            // DEBUG (boleh hapus nanti)
            echo "CARD MASUK: " . $card_id . "\n";

            if (!$card_id) {
                echo "CARD ID KOSONG!\n";
                return false;
            }

            // Cek masih IN
            $cek = $this->conn->prepare(
                "SELECT * FROM parkir 
                 WHERE card_id = :card_id 
                 AND status = 'IN'"
            );

            $cek->execute([
                ':card_id' => $card_id
            ]);

            if ($cek->rowCount() > 0) {
                echo "SUDAH CHECKIN\n";
                return false;
            }

            // ✅ INSERT SUDAH FIX (ADA PLAT)
            $insert = $this->conn->prepare(
                "INSERT INTO parkir 
                (card_id, checkin_time, status) 
                VALUES (:card_id, NOW(), 'IN')"
            );

            return $insert->execute([
                ':card_id' => $card_id,
            ]);

        } catch (Exception $e) {
            echo "CHECKIN ERROR: " . $e->getMessage();
            return false;
        }
    }

    // ====================
    // CHECK OUT (AMAN)
    // ====================
    public function checkOut($card_id)
    {
        try {

            if (!$card_id) {
                echo "CARD ID KOSONG!\n";
                return false;
            }

            $result = $this->conn->prepare(
                "SELECT * FROM parkir 
                 WHERE card_id = :card_id 
                 AND status = 'IN'
                 ORDER BY id DESC 
                 LIMIT 1"
            );

            $result->execute([
                ':card_id' => $card_id
            ]);

            if ($result->rowCount() == 0) {
                echo "DATA TIDAK DITEMUKAN\n";
                return false;
            }

            $data = $result->fetch(PDO::FETCH_ASSOC);

            $id = $data['id'];
            $checkin = strtotime($data['checkin_time']);
            $checkout = time();

            $duration = ceil(($checkout - $checkin) / 60);

            $fee_per_minute = 2000;
            $total_fee = $duration * $fee_per_minute;

            $update = $this->conn->prepare(
                "UPDATE parkir SET
                    checkout_time = NOW(),
                    duration = :duration,
                    fee = :fee,
                    status = 'WAITING'
                 WHERE id = :id"
            );

            $update->execute([
                ':duration' => $duration,
                ':fee' => $total_fee,
                ':id' => $id
            ]);

            return $total_fee;

        } catch (Exception $e) {
            echo "CHECKOUT ERROR: " . $e->getMessage();
            return false;
        }
    }

    // ====================
    // DATA WAITING
    // ====================
    public function getWaiting()
    {
        $stmt = $this->conn->query(
            "SELECT * FROM parkir 
             WHERE status='WAITING'
             ORDER BY id DESC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ====================
    // APPROVE
    // ====================
    public function approve($id)
    {
        $stmt = $this->conn->prepare(
            "UPDATE parkir 
             SET status='OUT'
             WHERE id=:id"
        );

        return $stmt->execute([
            ':id' => $id
        ]);
    }

    // ====================
    // HISTORY
    // ====================
    public function getHistory()
    {
        $stmt = $this->conn->query(
            "SELECT * FROM parkir 
             WHERE status='OUT'
             ORDER BY id DESC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}