<?php
require_once __DIR__ . '/../config/koneksi.php';

class Parkir {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    // =====================
    // LOGIN PLAIN TEXT
    // =====================
    public function login($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username=:u AND password=:p");
        $stmt->execute(['u'=>$username,'p'=>$password]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // =====================
    // CHECK-IN KENDARAAN
    // =====================
    public function checkin($card_id) {

        $stmt = $this->conn->prepare(
            "SELECT * FROM parkir 
             WHERE card_id=:c AND status='IN'"
        );
        $stmt->execute(['c'=>$card_id]);

        if($stmt->rowCount() > 0) return false;

        $stmt = $this->conn->prepare(
            "INSERT INTO parkir 
            (card_id, checkin_time, status) 
            VALUES (:c, NOW(), 'IN')"
        );

        return $stmt->execute(['c'=>$card_id]);
    }

    // =====================
    // CHECK-OUT KENDARAAN
    // =====================
    public function checkout($card_id) {

        $stmt = $this->conn->prepare(
            "SELECT * FROM parkir 
             WHERE card_id=:c 
             AND status='IN'
             ORDER BY id DESC 
             LIMIT 1"
        );

        $stmt->execute(['c'=>$card_id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$data) return false;

        // hanya ubah status jadi WAITING
        $stmt = $this->conn->prepare(
            "UPDATE parkir SET 
                status = 'WAITING'
             WHERE id = :id"
        );

        $stmt->execute([
            'id'=>$data['id']
        ]);

        return $data['id'];
    }

    // =====================
    // APPROVE TRANSAKSI
    // =====================
    public function complete($id) {

    $stmt = $this->conn->prepare(
        "UPDATE parkir 
         SET 
         checkout_time = NOW(),
         status='OUT'
         WHERE id=:id"
    );

    return $stmt->execute(['id'=>$id]);
}

    // =====================
    // SEDANG PARKIR (REALTIME)
    // =====================
    public function getCurrentParkir() {

        $stmt = $this->conn->query(
            "SELECT *,
            TIMESTAMPDIFF(MINUTE, checkin_time, NOW()) as duration,
            (TIMESTAMPDIFF(MINUTE, checkin_time, NOW()) * 2000) as fee
            FROM parkir 
            WHERE status='IN' 
            ORDER BY id DESC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // =====================
    // ANTRIAN KELUAR REALTIME
    // =====================
    public function getWaiting() {

        $stmt = $this->conn->query(
            "SELECT *,
            TIMESTAMPDIFF(MINUTE, checkin_time, NOW()) as duration,
            (TIMESTAMPDIFF(MINUTE, checkin_time, NOW()) * 2000) as fee
            FROM parkir 
            WHERE status='WAITING' 
            ORDER BY id DESC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // =====================
    // RIWAYAT
    // =====================
    public function getHistory() {

        $stmt = $this->conn->query(
            "SELECT * FROM parkir 
             WHERE status='OUT'
             ORDER BY id DESC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // =====================
    // AMBIL TRANSAKSI
    // =====================
    public function getTransaction($id) {

        $stmt = $this->conn->prepare(
            "SELECT * FROM parkir 
             WHERE id=:id"
        );

        $stmt->execute(['id'=>$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>